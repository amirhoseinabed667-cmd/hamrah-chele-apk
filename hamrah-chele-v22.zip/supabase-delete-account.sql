-- حذف کامل حساب کاربر جاری «همراه چله»
-- این کد را یک بار در Supabase > SQL Editor اجرا کنید.

create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    uid uuid;
begin
    uid := (select auth.uid());

    if uid is null then
        raise exception 'Not authenticated';
    end if;

    -- حذف اطلاعات برنامه کاربر
    delete from public.user_data
    where user_id = uid;

    -- حذف خود حساب کاربری
    delete from auth.users
    where id = uid;
end;
$$;

revoke execute on function public.delete_my_account() from public;
revoke execute on function public.delete_my_account() from anon;
grant execute on function public.delete_my_account() to authenticated;
