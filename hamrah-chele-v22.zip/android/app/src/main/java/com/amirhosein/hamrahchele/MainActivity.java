package com.amirhosein.hamrahchele;

import android.os.Bundle;
import android.graphics.Color;
import android.os.Handler;
import android.widget.Toast;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setBackgroundDrawableResource(com.amirhosein.hamrahchele.R.drawable.native_splash_background);
        super.onCreate(savedInstanceState);

        if (getBridge() != null && getBridge().getWebView() != null) {
            // Keep the native splash artwork visible through the WebView until
            // the first web page content is actually drawn.
            getBridge().getWebView().setBackgroundColor(Color.TRANSPARENT);
        }
    }

    private boolean waitingForSecondBack = false;
    private final Handler backHandler = new Handler();

    @Override
    public void onBackPressed() {
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().evaluateJavascript(
                "(() => {" +
                "const d=document.getElementById('detail');" +
                "const m=document.getElementById('managementPage');" +
                "const h=document.getElementById('habitsPage');" +
                "return (m && !m.classList.contains('hidden') && (!d || d.classList.contains('hidden')) && (!h || h.classList.contains('hidden')) && !window.archiveMode) ? 'HOME' : 'INNER';" +
                "})()",
                value -> {
                    if ("\"HOME\"".equals(value)) {
                        if (waitingForSecondBack) {
                            backHandler.removeCallbacksAndMessages(null);
                            MainActivity.super.onBackPressed();
                        } else {
                            waitingForSecondBack = true;
                            Toast.makeText(
                                MainActivity.this,
                                "برای خروج، دوباره دکمه برگشت را بزنید",
                                Toast.LENGTH_SHORT
                            ).show();
                            backHandler.postDelayed(() -> waitingForSecondBack = false, 2000);
                        }
                    } else {
                        waitingForSecondBack = false;
                        getBridge().getWebView().evaluateJavascript("history.back()", null);
                    }
                }
            );
        } else {
            super.onBackPressed();
        }
    }
}
